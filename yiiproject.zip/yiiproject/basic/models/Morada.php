<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "morada".
 *
 * @property int $id_morada
 * @property string $rua
 * @property int $n_porta
 * @property int $cod_postal
 *
 * @property Empresa[] $empresas
 * @property Funcionario[] $funcionarios
 * @property CodPostal $codPostal
 * @property Porto[] $portos
 */
class Morada extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'morada';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['rua', 'n_porta', 'cod_postal'], 'required'],
            [['n_porta', 'cod_postal'], 'integer'],
            [['rua'], 'string', 'max' => 40],
            [['cod_postal'], 'exist', 'skipOnError' => true, 'targetClass' => CodPostal::className(), 'targetAttribute' => ['cod_postal' => 'cod_postal']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_morada' => 'Id Morada',
            'rua' => 'Rua',
            'n_porta' => 'N Porta',
            'cod_postal' => 'Cod Postal',
        ];
    }

    /**
     * Gets query for [[Empresas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmpresas()
    {
        return $this->hasMany(Empresa::className(), ['id_morada' => 'id_morada']);
    }

    /**
     * Gets query for [[Funcionarios]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFuncionarios()
    {
        return $this->hasMany(Funcionario::className(), ['id_morada' => 'id_morada']);
    }

    /**
     * Gets query for [[CodPostal]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCodPostal()
    {
        return $this->hasOne(CodPostal::className(), ['cod_postal' => 'cod_postal']);
    }

    /**
     * Gets query for [[Portos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPortos()
    {
        return $this->hasMany(Porto::className(), ['id_morada' => 'id_morada']);
    }
}
