<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "contentor".
 *
 * @property int $id_contentor
 * @property float $capacidade
 * @property string $origem_carga
 * @property string $carga
 * @property string $zona_cont
 *
 * @property LinhaComboio[] $linhaComboios
 * @property LinhaNavio[] $linhaNavios
 * @property LinhaPorto[] $linhaPortos
 */
class Contentor extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'contentor';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_contentor', 'capacidade', 'origem_carga', 'carga', 'zona_cont'], 'required'],
            [['id_contentor'], 'integer'],
            [['capacidade'], 'number'],
            [['origem_carga'], 'string', 'max' => 15],
            [['carga'], 'string', 'max' => 50],
            [['zona_cont'], 'string', 'max' => 40],
            [['id_contentor'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_contentor' => 'Id Contentor',
            'capacidade' => 'Capacidade',
            'origem_carga' => 'Origem Carga',
            'carga' => 'Carga',
            'zona_cont' => 'Zona Cont',
        ];
    }

    /**
     * Gets query for [[LinhaComboios]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getLinhaComboios()
    {
        return $this->hasMany(LinhaComboio::className(), ['id_contentor' => 'id_contentor']);
    }

    /**
     * Gets query for [[LinhaNavios]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getLinhaNavios()
    {
        return $this->hasMany(LinhaNavio::className(), ['id_contentor' => 'id_contentor']);
    }

    /**
     * Gets query for [[LinhaPortos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getLinhaPortos()
    {
        return $this->hasMany(LinhaPorto::className(), ['id_contentor' => 'id_contentor']);
    }
}
