<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "comboio".
 *
 * @property int $id_comboio
 * @property float $capacidade
 * @property string $origem
 *
 * @property LinhaComboio[] $linhaComboios
 */
class Comboio extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'comboio';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['capacidade', 'origem'], 'required'],
            [['capacidade'], 'number'],
            [['origem'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_comboio' => 'Id Comboio',
            'capacidade' => 'Capacidade',
            'origem' => 'Origem',
        ];
    }

    /**
     * Gets query for [[LinhaComboios]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getLinhaComboios()
    {
        return $this->hasMany(LinhaComboio::className(), ['id_comboio' => 'id_comboio']);
    }
}
