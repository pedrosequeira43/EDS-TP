<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "empresa".
 *
 * @property int $id_empresa
 * @property string $nome
 * @property string $email
 * @property int $id_morada
 *
 * @property Morada $morada
 * @property Funcionario[] $funcionarios
 * @property Porto[] $portos
 * @property TelefoneEmpresa[] $telefoneEmpresas
 */
class Empresa extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'empresa';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nome', 'email', 'id_morada'], 'required'],
            [['id_morada'], 'integer'],
            [['nome'], 'string', 'max' => 80],
            [['email'], 'string', 'max' => 40],
            [['id_morada'], 'exist', 'skipOnError' => true, 'targetClass' => Morada::className(), 'targetAttribute' => ['id_morada' => 'id_morada']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_empresa' => 'Id Empresa',
            'nome' => 'Nome',
            'email' => 'Email',
            'id_morada' => 'Id Morada',
        ];
    }

    /**
     * Gets query for [[Morada]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMorada()
    {
        return $this->hasOne(Morada::className(), ['id_morada' => 'id_morada']);
    }

    /**
     * Gets query for [[Funcionarios]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFuncionarios()
    {
        return $this->hasMany(Funcionario::className(), ['id_empresa' => 'id_empresa']);
    }

    /**
     * Gets query for [[Portos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPortos()
    {
        return $this->hasMany(Porto::className(), ['id_empresa' => 'id_empresa']);
    }

    /**
     * Gets query for [[TelefoneEmpresas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTelefoneEmpresas()
    {
        return $this->hasMany(TelefoneEmpresa::className(), ['id_empresa' => 'id_empresa']);
    }
}
