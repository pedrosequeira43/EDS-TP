<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "porto".
 *
 * @property int $id_porto
 * @property string $nome
 * @property string $email
 * @property string $horario_func
 * @property int $calado_entra
 * @property int $calado_saida
 * @property int $id_morada
 * @property int $id_empresa
 *
 * @property Grua[] $gruas
 * @property LinhaPorto[] $linhaPortos
 * @property Empresa $empresa
 * @property Morada $morada
 * @property TelefonePorto[] $telefonePortos
 */
class Porto extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'porto';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nome', 'desc_carg', 'horario_func', 'calado_entra', 'calado_saida', 'id_morada', 'id_empresa'], 'required'],
            [['horario_func'], 'safe'],
            [['calado_entra', 'calado_saida', 'id_morada', 'id_empresa'], 'integer'],
            [['nome'], 'string', 'max' => 80],
            [['email'], 'string', 'max' => 40],
            [['id_empresa'], 'exist', 'skipOnError' => true, 'targetClass' => Empresa::className(), 'targetAttribute' => ['id_empresa' => 'id_empresa']],
            [['id_morada'], 'exist', 'skipOnError' => true, 'targetClass' => Morada::className(), 'targetAttribute' => ['id_morada' => 'id_morada']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_porto' => 'Id Porto',
            'nome' => 'Nome',
            'desc_carg ' => 'Desc_carg ',
            'horario_func' => 'Horario Func',
            'calado_entra' => 'Calado Entra',
            'calado_saida' => 'Calado Saida',
            'id_morada' => 'Id Morada',
            'id_empresa' => 'Id Empresa',
        ];
    }

    /**
     * Gets query for [[Gruas]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getGruas()
    {
        return $this->hasMany(Grua::className(), ['id_porto' => 'id_porto']);
    }

    /**
     * Gets query for [[LinhaPortos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getLinhaPortos()
    {
        return $this->hasMany(LinhaPorto::className(), ['id_porto' => 'id_porto']);
    }

    /**
     * Gets query for [[Empresa]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmpresa()
    {
        return $this->hasOne(Empresa::className(), ['id_empresa' => 'id_empresa']);
    }

    /**
     * Gets query for [[Morada]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMorada()
    {
        return $this->hasOne(Morada::className(), ['id_morada' => 'id_morada']);
    }

    /**
     * Gets query for [[TelefonePortos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTelefonePortos()
    {
        return $this->hasMany(TelefonePorto::className(), ['id_porto' => 'id_porto']);
    }

    public function getNomePorto()
    {
        return $this->hasMany(Porto::className(), ['nome' => 'nome']);
    }
}
