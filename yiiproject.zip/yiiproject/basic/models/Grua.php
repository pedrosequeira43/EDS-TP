<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "grua".
 *
 * @property int|null $id_grua
 * @property string $zona
 * @property int $id_porto
 *
 * @property Porto $porto
 */
class Grua extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'grua';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id_grua', 'id_porto'], 'integer'],
            [['zona', 'id_porto'], 'required'],
            [['zona'], 'string', 'max' => 80],
            [['id_porto'], 'exist', 'skipOnError' => true, 'targetClass' => Porto::className(), 'targetAttribute' => ['id_porto' => 'id_porto']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_grua' => 'Id Grua',
            'zona' => 'Zona',
            'id_porto' => 'Id Porto',
        ];
    }

    /**
     * Gets query for [[Porto]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPorto()
    {
        return $this->hasOne(Porto::className(), ['id_porto' => 'id_porto']);
    }
}
