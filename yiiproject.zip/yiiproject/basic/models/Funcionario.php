<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "funcionario".
 *
 * @property int $id_funcionario
 * @property string $nome
 * @property string $email
 * @property string $horario_trab
 * @property int $id_morada
 * @property int $id_empresa
 *
 * @property Empresa $empresa
 * @property Morada $morada
 * @property TelefoneFunci[] $telefoneFuncis
 */
class Funcionario extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'funcionario';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nome', 'email', 'horario_trab', 'id_morada', 'id_empresa'], 'required'],
            [['horario_trab'], 'safe'],
            [['id_morada', 'id_empresa'], 'integer'],
            [['nome'], 'string', 'max' => 80],
            [['email'], 'string', 'max' => 40],
            [['id_empresa'], 'exist', 'skipOnError' => true, 'targetClass' => Empresa::className(), 'targetAttribute' => ['id_empresa' => 'id_empresa']],
            [['id_morada'], 'exist', 'skipOnError' => true, 'targetClass' => Morada::className(), 'targetAttribute' => ['id_morada' => 'id_morada']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_funcionario' => 'Id Funcionario',
            'nome' => 'Nome',
            'email' => 'Email',
            'horario_trab' => 'Horario Trab',
            'id_morada' => 'Id Morada',
            'id_empresa' => 'Id Empresa',
        ];
    }

    /**
     * Gets query for [[Empresa]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEmpresa()
    {
        return $this->hasOne(Empresa::className(), ['id_empresa' => 'id_empresa']);
    }

    /**
     * Gets query for [[Morada]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMorada()
    {
        return $this->hasOne(Morada::className(), ['id_morada' => 'id_morada']);
    }

    /**
     * Gets query for [[TelefoneFuncis]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTelefoneFuncis()
    {
        return $this->hasMany(TelefoneFunci::className(), ['id_funcionario' => 'id_funcionario']);
    }
}
