<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Porto;
use app\models\Grua;

/* @var $this yii\web\View */
/* @var $model app\models\Grua */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="grua-form">

    <?php $form = ActiveForm::begin(); ?>

    <!-- <?= $form->field($model, 'id_grua')->textInput() ?> -->

    <!-- <?= $form->field($model, 'zona')->textInput(['maxlength' => true]) ?> -->
    <?= $form->field($model, 'zona')->dropDownList(
        ArrayHelper::map(Grua::find()->all(), 'zona','zona'),
        ['prompt'=>'Select Zona'])?>


    <!-- /*<?= $form->field($model, 'id_porto')->textInput() ?> */ -->
    <?= $form->field($model, 'id_porto')->dropDownList(
        ArrayHelper::map(Porto::find()->all(), 'id_porto','nome'),
        ['prompt'=>'Select Porto'])?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
