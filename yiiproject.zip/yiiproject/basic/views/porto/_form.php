<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use app\models\Morada;
use app\models\Empresa;

/* @var $this yii\web\View */
/* @var $model app\models\Porto */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="porto-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'nome')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'horario_func')->textInput() ?>

<!--     <?= $form->field($model, 'calado_entra')->textInput() ?>

    <?= $form->field($model, 'calado_saida')->textInput() ?> -->

    <!-- <?= $form->field($model, 'id_morada')->textInput() ?> -->
    <?= $form->field($model, 'id_morada')->dropDownList(
        ArrayHelper::map(Morada::find()->all(), 'id_morada','rua'),
        ['prompt'=>'Select Morada'])?>
    

    <!-- <?= $form->field($model, 'id_empresa')->textInput() ?> -->
    <?= $form->field($model, 'id_empresa')->dropDownList(
        ArrayHelper::map(Empresa::find()->all(), 'id_empresa','nome'),
        ['prompt'=>'Select Empresa'])?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
