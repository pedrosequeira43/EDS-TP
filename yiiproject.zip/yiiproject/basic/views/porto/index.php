<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\PortoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Portos';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="porto-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Porto', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id_porto',
            'nome',
            'email:email',
            'horario_func',
            'calado_entra',
            //'calado_saida',
            //'id_morada',
            //'id_empresa',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
