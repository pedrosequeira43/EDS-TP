<?php

/* @var $this yii\web\View */

$this->title = 'Porto Mar';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Bem Vindo!</h1>




    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-6">
                <h2>Capitão</h2>

                <p>Faça o requesito de atracagem do navio.</p>

                <p><a class="btn btn-default" href="http://localhost/yiiproject/basic/web/site/login">Login &raquo;</a></p>
            </div>
            <div class="col-lg-6">
                <h2>Funcionário</h2>

                <p>Requesite a grua para descarregar o navio e requesite o comboio para exportação.</p>

                <p><a class="btn btn-default" href="http://localhost/yiiproject/basic/web/site/login">Login &raquo;</a></p>
            </div>

        </div>

    </div>
</div>
