<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Contentor */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="contentor-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id_contentor')->textInput() ?>

    <?= $form->field($model, 'capacidade')->textInput() ?>

    <?= $form->field($model, 'origem_carga')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'carga')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'zona_cont')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
