<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Comboio */

$this->title = 'Update Comboio: ' . $model->id_comboio;
$this->params['breadcrumbs'][] = ['label' => 'Comboios', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_comboio, 'url' => ['view', 'id' => $model->id_comboio]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="comboio-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
