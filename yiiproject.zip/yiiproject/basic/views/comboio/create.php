<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Comboio */

$this->title = 'Create Comboio';
$this->params['breadcrumbs'][] = ['label' => 'Comboios', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="comboio-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
