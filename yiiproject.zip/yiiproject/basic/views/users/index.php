<?php

foreach($users as $user){
    echo $user->username."<br>";
}

?>